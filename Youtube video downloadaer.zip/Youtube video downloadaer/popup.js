document.getElementById('downloadForm').addEventListener('submit', async function(event) {
    event.preventDefault();  // Prevent default form submission

    const formData = new FormData();
    const videoLink = document.getElementById('videoLink').value;
    formData.append('link', videoLink);  // Append video link to form data

    try {
        // Send form data using fetch API
        const response = await fetch('http://127.0.0.1:8000/download', {
            method: 'POST',
            body: formData
        });

        // Handle the response
        const result = await response.json();
        document.getElementById('statusMessage').innerText = result.message || 'Download complete!';
    } catch (error) {
        document.getElementById('statusMessage').innerText = 'An error occurred during the download.';
    }
});
