from fastapi import FastAPI, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
import yt_dlp
from datetime import datetime

app = FastAPI()

# Allow all origins for CORS (adjust for security in production)
allow_origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allow_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create a 'downloads' directory if it doesn't exist
downloads_dir = os.path.join(os.getcwd(), "downloads")
if not os.path.exists(downloads_dir):
    os.makedirs(downloads_dir)

# Serve static files from the 'downloads' directory
app.mount("/downloads", StaticFiles(directory=downloads_dir), name="downloads")

@app.post("/download")
async def download_video(link: str = Form(...)):  
    try:
        # Extract video metadata (like title)
        with yt_dlp.YoutubeDL({"quiet": True}) as ydl:
            info_dict = ydl.extract_info(link, download=False)
            video_title = info_dict.get('title', 'video').replace(' ', '_')

        # Generate a unique filename using timestamp and video title
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        filename = f"{timestamp}_{video_title}.mp4"
        output_path = os.path.join(downloads_dir, filename)

        # Define download options
        youtube_dl_options = {
            "format": "best",
            "outtmpl": output_path  # Save video in 'downloads' directory
        }

        # Start download
        with yt_dlp.YoutubeDL(youtube_dl_options) as ydl:
            ydl.download([link])

        # Return the success message along with file location and download link
        return {
            "message": "Download complete!",
            "video_title": video_title,
            "file_name": filename,
            "download_link": f"/downloads/{filename}",
            "status": "success"
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error downloading video: {str(e)}")

